@echo off
title RetroCalcLang Compiler Demo
color 0B
cls

echo ==========================================
echo    RETROCALCLANG COMPILER DEMO
echo ==========================================
echo.
echo This script will run the compiler samples automatically.
echo.
pause

echo.
echo [1/3] RUNNING ARITHMETIC SAMPLE...
echo ------------------------------------------
python compiler.py samples/arithmetic.src --debug
echo.
echo Arithmetic Demo Finished.
pause

echo.
echo [2/3] RUNNING LOOPS AND CONDITIONS...
echo ------------------------------------------
python compiler.py samples/loops.src --debug
echo.
echo Loops Demo Finished.
pause

echo.
echo [3/3] RUNNING MATH FUNCTIONS (sin, sqrt, etc.)...
echo ------------------------------------------
python compiler.py samples/functions.src --debug
echo.
echo All Demos Completed Successfully!
echo ==========================================
pause
