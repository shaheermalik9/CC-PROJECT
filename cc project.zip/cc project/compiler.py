import re
import sys
import math
import argparse

# =============================================================================
# 1. LEXICAL ANALYZER (LEXER)
# =============================================================================

class Token:
    def __init__(self, type, value, line, column):
        self.type = type
        self.value = value
        self.line = line
        self.column = column

    def __repr__(self):
        return f"Token({self.type}, {repr(self.value)}, line={self.line}, col={self.column})"

class Lexer:
    TOKEN_SPEC = [
        ('COMMENT',  r'#.*'),               
        ('NUMBER',   r'\d+(\.\d*)?'),       
        ('IF',       r'\bif\b'),            
        ('WHILE',    r'\bwhile\b'),         
        ('PRINT',    r'\bprint\b'),         
        ('SIN',      r'\bsin\b'),
        ('COS',      r'\bcos\b'),
        ('TAN',      r'\btan\b'),
        ('LOG',      r'\blog\b'),
        ('SQRT',     r'\bsqrt\b'),
        ('PI',       r'\bpi\b'),
        ('E',        r'\be\b'),
        ('IDENT',    r'[a-zA-Z_][a-zA-Z0-9_]*'), 
        ('EQ',       r'=='),                
        ('NEQ',      r'!='),                
        ('LE',       r'<='),                
        ('GE',       r'>='),                
        ('ASSIGN',   r'='),                 
        ('PLUS',     r'\+'),                
        ('MINUS',    r'-'),                 
        ('MUL',      r'\*'),                
        ('DIV',      r'/'),                 
        ('POW',      r'\^'),                
        ('LT',       r'<'),                 
        ('GT',       r'>'),                 
        ('LPAREN',   r'\('),                
        ('RPAREN',   r'\)'),                
        ('LBRACE',   r'\{'),                
        ('RBRACE',   r'\}'),                
        ('COMMA',    r','),                 
        ('NEWLINE',  r'\n'),                
        ('SKIP',     r'[ \t\r]+'),          
        ('MISMATCH', r'.'),                 
    ]

    def __init__(self, source_code):
        self.source_code = source_code
        self.line_num = 1
        self.line_start = 0

    def tokenize(self):
        tokens = []
        tok_regex = '|'.join('(?P<%s>%s)' % pair for pair in self.TOKEN_SPEC)
        for mo in re.finditer(tok_regex, self.source_code):
            kind = mo.lastgroup
            value = mo.group()
            column = mo.start() - self.line_start + 1
            if kind == 'NUMBER':
                value = float(value) if '.' in value else int(value)
            elif kind == 'COMMENT' or kind == 'SKIP':
                continue
            elif kind == 'NEWLINE':
                self.line_start = mo.end()
                self.line_num += 1
                continue
            elif kind == 'MISMATCH':
                print(f"Lexical Error: Unexpected character '{value}' at line {self.line_num}, column {column}")
                sys.exit(1)
            
            tokens.append(Token(kind, value, self.line_num, column))
        return tokens

# =============================================================================
# 2. SYNTAX ANALYSIS (PARSER)
# =============================================================================

class ASTNode: pass
class ProgramNode(ASTNode):
    def __init__(self, statements): self.statements = statements
class AssignmentNode(ASTNode):
    def __init__(self, name, value): self.name = name; self.value = value
class PrintNode(ASTNode):
    def __init__(self, expression): self.expression = expression
class IfNode(ASTNode):
    def __init__(self, condition, body): self.condition = condition; self.body = body
class WhileNode(ASTNode):
    def __init__(self, condition, body): self.condition = condition; self.body = body
class BinaryOpNode(ASTNode):
    def __init__(self, left, op, right): self.left = left; self.op = op; self.right = right
class UnaryOpNode(ASTNode):
    def __init__(self, op, operand): self.op = op; self.operand = operand
class FunctionCallNode(ASTNode):
    def __init__(self, func_name, argument): self.func_name = func_name; self.argument = argument
class NumberNode(ASTNode):
    def __init__(self, value): self.value = value
class IdentifierNode(ASTNode):
    def __init__(self, name): self.name = name
class ConstantNode(ASTNode):
    def __init__(self, name, value): self.name = name; self.value = value

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def error(self, message):
        token = self.tokens[self.pos] if self.pos < len(self.tokens) else self.tokens[-1]
        print(f"Syntax Error: {message} at line {token.line}, column {token.column}")
        sys.exit(1)

    def consume(self, expected_type):
        if self.pos < len(self.tokens) and self.tokens[self.pos].type == expected_type:
            token = self.tokens[self.pos]
            self.pos += 1
            return token
        else:
            actual = self.tokens[self.pos].type if self.pos < len(self.tokens) else "EOF"
            self.error(f"Expected {expected_type}, got {actual}")

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def parse(self):
        statements = []
        while self.pos < len(self.tokens) and self.peek().type != 'RBRACE':
            statements.append(self.parse_statement())
        return ProgramNode(statements)

    def parse_statement(self):
        token = self.peek()
        if token.type == 'PRINT': return self.parse_print()
        elif token.type == 'IF': return self.parse_if()
        elif token.type == 'WHILE': return self.parse_while()
        elif token.type == 'IDENT' and self.pos + 1 < len(self.tokens) and self.tokens[self.pos+1].type == 'ASSIGN':
            return self.parse_assignment()
        return self.parse_expression()

    def parse_assignment(self):
        name = self.consume('IDENT').value
        self.consume('ASSIGN')
        return AssignmentNode(name, self.parse_expression())

    def parse_print(self):
        self.consume('PRINT'); return PrintNode(self.parse_expression())

    def parse_if(self):
        self.consume('IF'); cond = self.parse_expression()
        self.consume('LBRACE'); body = self.parse(); self.consume('RBRACE')
        return IfNode(cond, body)

    def parse_while(self):
        self.consume('WHILE'); cond = self.parse_expression()
        self.consume('LBRACE'); body = self.parse(); self.consume('RBRACE')
        return WhileNode(cond, body)

    def parse_expression(self): return self.parse_comparison()

    def parse_comparison(self):
        left = self.parse_arithmetic()
        if self.peek() and self.peek().type in ('LT', 'GT', 'LE', 'GE', 'EQ', 'NEQ'):
            op = self.consume(self.peek().type).type
            return BinaryOpNode(left, op, self.parse_arithmetic())
        return left

    def parse_arithmetic(self):
        node = self.parse_term()
        while self.peek() and self.peek().type in ('PLUS', 'MINUS'):
            op = self.consume(self.peek().type).type
            node = BinaryOpNode(node, op, self.parse_term())
        return node

    def parse_term(self):
        node = self.parse_factor()
        while self.peek() and self.peek().type in ('MUL', 'DIV'):
            op = self.consume(self.peek().type).type
            node = BinaryOpNode(node, op, self.parse_factor())
        return node

    def parse_factor(self):
        node = self.parse_power()
        if self.peek() and self.peek().type == 'POW':
            op = self.consume('POW').type
            node = BinaryOpNode(node, op, self.parse_factor())
        return node

    def parse_power(self):
        if self.peek() and self.peek().type == 'MINUS':
            self.consume('MINUS')
            return UnaryOpNode('UNARY_MINUS', self.parse_power())
        return self.parse_primary()

    def parse_primary(self):
        token = self.peek()
        if token.type == 'NUMBER': return NumberNode(self.consume('NUMBER').value)
        if token.type == 'IDENT': return IdentifierNode(self.consume('IDENT').value)
        if token.type == 'PI': self.consume('PI'); return ConstantNode('pi', math.pi)
        if token.type == 'E': self.consume('E'); return ConstantNode('e', math.e)
        if token.type in ('SIN', 'COS', 'TAN', 'LOG', 'SQRT'):
            func = self.consume(token.type).value
            self.consume('LPAREN'); arg = self.parse_expression(); self.consume('RPAREN')
            return FunctionCallNode(func, arg)
        if token.type == 'LPAREN':
            self.consume('LPAREN'); node = self.parse_expression(); self.consume('RPAREN')
            return node
        self.error(f"Unexpected token {token.type}")

# =============================================================================
# 3. SEMANTIC ANALYSIS
# =============================================================================

class SemanticAnalyzer:
    def __init__(self): self.symbol_table = {}
    def error(self, message): print(f"Semantic Error: {message}"); sys.exit(1)
    def analyze(self, node):
        if isinstance(node, ProgramNode):
            for s in node.statements: self.analyze(s)
        elif isinstance(node, AssignmentNode):
            self.analyze(node.value); self.symbol_table[node.name] = 'NUMBER'
        elif isinstance(node, PrintNode): self.analyze(node.expression)
        elif isinstance(node, IfNode) or isinstance(node, WhileNode):
            self.analyze(node.condition); self.analyze(node.body)
        elif isinstance(node, BinaryOpNode): self.analyze(node.left); self.analyze(node.right)
        elif isinstance(node, UnaryOpNode): self.analyze(node.operand)
        elif isinstance(node, FunctionCallNode): self.analyze(node.argument)
        elif isinstance(node, IdentifierNode):
            if node.name not in self.symbol_table: self.error(f"Undefined variable '{node.name}'")

# =============================================================================
# 4. IR GENERATION (TAC)
# =============================================================================

class Instruction:
    def __init__(self, op, arg1=None, arg2=None, result=None):
        self.op, self.arg1, self.arg2, self.result = op, arg1, arg2, result
    def __repr__(self):
        ops = {'PLUS':'+', 'MINUS':'-', 'MUL':'*', 'DIV':'/', 'POW':'^', 'LT':'<', 'GT':'>', 'LE':'<=', 'GE':'>=', 'EQ':'==', 'NEQ':'!='}
        if self.op == 'ASSIGN': return f"{self.result} = {self.arg1}"
        if self.op in ops: return f"{self.result} = {self.arg1} {ops[self.op]} {self.arg2}"
        if self.op == 'UNARY_MINUS': return f"{self.result} = -{self.arg1}"
        if self.op == 'CALL': return f"{self.result} = {self.arg1}({self.arg2})"
        if self.op == 'PRINT': return f"PRINT {self.arg1}"
        if self.op == 'LABEL': return f"LABEL {self.arg1}:"
        if self.op == 'GOTO': return f"GOTO {self.arg1}"
        if self.op == 'IF_FALSE_GOTO': return f"IF NOT {self.arg1} GOTO {self.arg2}"
        return f"{self.op} {self.arg1} {self.arg2} {self.result}"

class TACGenerator:
    def __init__(self):
        self.instructions = []; self.t_cnt = 0; self.l_cnt = 0
    def new_t(self): self.t_cnt += 1; return f"t{self.t_cnt}"
    def new_l(self): self.l_cnt += 1; return f"L{self.l_cnt}"
    def generate(self, node):
        if isinstance(node, ProgramNode):
            for s in node.statements: self.generate(s)
        elif isinstance(node, AssignmentNode):
            self.instructions.append(Instruction('ASSIGN', self.generate(node.value), result=node.name))
        elif isinstance(node, PrintNode):
            self.instructions.append(Instruction('PRINT', self.generate(node.expression)))
        elif isinstance(node, IfNode):
            cond, l_end = self.generate(node.condition), self.new_l()
            self.instructions.append(Instruction('IF_FALSE_GOTO', cond, l_end))
            self.generate(node.body); self.instructions.append(Instruction('LABEL', l_end))
        elif isinstance(node, WhileNode):
            l_start, l_end = self.new_l(), self.new_l()
            self.instructions.append(Instruction('LABEL', l_start))
            cond = self.generate(node.condition)
            self.instructions.append(Instruction('IF_FALSE_GOTO', cond, l_end))
            self.generate(node.body); self.instructions.append(Instruction('GOTO', l_start))
            self.instructions.append(Instruction('LABEL', l_end))
        elif isinstance(node, BinaryOpNode):
            l, r, t = self.generate(node.left), self.generate(node.right), self.new_t()
            self.instructions.append(Instruction(node.op, l, r, t)); return t
        elif isinstance(node, UnaryOpNode):
            t = self.new_t(); self.instructions.append(Instruction('UNARY_MINUS', self.generate(node.operand), result=t)); return t
        elif isinstance(node, FunctionCallNode):
            t = self.new_t(); self.instructions.append(Instruction('CALL', node.func_name, self.generate(node.argument), t)); return t
        elif isinstance(node, NumberNode): return node.value
        elif isinstance(node, IdentifierNode): return node.name
        elif isinstance(node, ConstantNode): return node.value

# =============================================================================
# 5. OPTIMIZATION
# =============================================================================

class Optimizer:
    def __init__(self, instrs): self.instrs = instrs
    def optimize(self):
        changed = True
        while changed:
            self.instrs, c1 = self.fold(self.instrs)
            self.instrs, c2 = self.dce(self.instrs)
            changed = c1 or c2
        return self.instrs
    def fold(self, instrs):
        new, changed, consts = [], False, {}
        for i in instrs:
            a1, a2 = consts.get(i.arg1, i.arg1), consts.get(i.arg2, i.arg2)
            if i.op in ('PLUS','MINUS','MUL','DIV','POW','LT','GT','LE','GE','EQ','NEQ') and isinstance(a1,(int,float)) and isinstance(a2,(int,float)):
                r = None
                if i.op == 'PLUS': r = a1 + a2
                elif i.op == 'MINUS': r = a1 - a2
                elif i.op == 'MUL': r = a1 * a2
                elif i.op == 'DIV': r = a1 / a2 if a2 != 0 else 0
                elif i.op == 'POW': r = a1 ** a2
                elif i.op == 'LT': r = 1 if a1 < a2 else 0
                elif i.op == 'GT': r = 1 if a1 > a2 else 0
                elif i.op == 'LE': r = 1 if a1 <= a2 else 0
                elif i.op == 'GE': r = 1 if a1 >= a2 else 0
                elif i.op == 'EQ': r = 1 if a1 == a2 else 0
                elif i.op == 'NEQ': r = 1 if a1 != a2 else 0
                if r is not None:
                    new.append(Instruction('ASSIGN', r, result=i.result))
                    if i.result.startswith('t'): consts[i.result] = r
                    changed = True; continue
            elif i.op == 'CALL' and isinstance(a2,(int,float)):
                r = None
                if i.arg1 == 'sin': r = math.sin(a2)
                elif i.arg1 == 'cos': r = math.cos(a2)
                elif i.arg1 == 'tan': r = math.tan(a2)
                elif i.arg1 == 'log': r = math.log(a2) if a2 > 0 else 0
                elif i.arg1 == 'sqrt': r = math.sqrt(a2) if a2 >= 0 else 0
                if r is not None:
                    new.append(Instruction('ASSIGN', r, result=i.result))
                    if i.result.startswith('t'): consts[i.result] = r
                    changed = True; continue
            elif i.op == 'ASSIGN' and isinstance(a1,(int,float)) and i.result.startswith('t'): consts[i.result] = a1
            new.append(Instruction(i.op, a1, a2, i.result))
        return new, changed
    def dce(self, instrs):
        used = {i.arg1 for i in instrs if isinstance(i.arg1,str)} | {i.arg2 for i in instrs if isinstance(i.arg2,str)}
        new = [i for i in instrs if not (i.op == 'ASSIGN' and i.result.startswith('t') and i.result not in used)]
        return new, len(new) != len(instrs)

# =============================================================================
# 6. VIRTUAL MACHINE (EXECUTION)
# =============================================================================

class VM:
    def __init__(self, instrs):
        self.instrs, self.vars, self.ip = instrs, {}, 0
        self.lbls = {i.arg1: idx for idx, i in enumerate(instrs) if i.op == 'LABEL'}
    def val(self, x):
        if isinstance(x, (int, float)): return x
        return self.vars.get(x, 0)
    def run(self):
        while self.ip < len(self.instrs):
            i = self.instrs[self.ip]
            if i.op == 'ASSIGN': self.vars[i.result] = self.val(i.arg1)
            elif i.op == 'PLUS': self.vars[i.result] = self.val(i.arg1) + self.val(i.arg2)
            elif i.op == 'MINUS': self.vars[i.result] = self.val(i.arg1) - self.val(i.arg2)
            elif i.op == 'MUL': self.vars[i.result] = self.val(i.arg1) * self.val(i.arg2)
            elif i.op == 'DIV': 
                d = self.val(i.arg2)
                if d == 0: print("Runtime Error: Division by zero"); sys.exit(1)
                self.vars[i.result] = self.val(i.arg1) / d
            elif i.op == 'POW': self.vars[i.result] = self.val(i.arg1) ** self.val(i.arg2)
            elif i.op == 'UNARY_MINUS': self.vars[i.result] = -self.val(i.arg1)
            elif i.op in ('LT','GT','LE','GE','EQ','NEQ'):
                a1, a2 = self.val(i.arg1), self.val(i.arg2)
                res = 0
                if i.op == 'LT': res = 1 if a1 < a2 else 0
                elif i.op == 'GT': res = 1 if a1 > a2 else 0
                elif i.op == 'LE': res = 1 if a1 <= a2 else 0
                elif i.op == 'GE': res = 1 if a1 >= a2 else 0
                elif i.op == 'EQ': res = 1 if a1 == a2 else 0
                elif i.op == 'NEQ': res = 1 if a1 != a2 else 0
                self.vars[i.result] = res
            elif i.op == 'CALL':
                a, f = self.val(i.arg2), i.arg1
                if f == 'sin': r = math.sin(a)
                elif f == 'cos': r = math.cos(a)
                elif f == 'tan': r = math.tan(a)
                elif f == 'log': r = math.log(a) if a > 0 else 0
                elif f == 'sqrt': r = math.sqrt(a) if a >= 0 else 0
                else: r = 0
                self.vars[i.result] = r
            elif i.op == 'PRINT':
                v = self.val(i.arg1)
                print(int(v) if isinstance(v, float) and v.is_integer() else v)
            elif i.op == 'GOTO': self.ip = self.lbls[i.arg1]; continue
            elif i.op == 'IF_FALSE_GOTO':
                if self.val(i.arg1) == 0: self.ip = self.lbls[i.arg2]; continue
            self.ip += 1

def repl():
    print("RetroCalcLang Interactive REPL")
    print("Type 'exit' to quit.")
    vm = VM([])
    # We keep the VM state alive across inputs
    while True:
        try:
            line = input("retro> ")
            if line.strip().lower() == 'exit': break
            if not line.strip(): continue
            
            lexer = Lexer(line)
            tokens = lexer.tokenize()
            parser_obj = Parser(tokens)
            ast = parser_obj.parse()
            
            ir_gen = TACGenerator()
            ir_gen.generate(ast)
            
            vm.instrs = ir_gen.instructions
            vm.ip = 0
            vm.lbls = {i.arg1: idx for idx, i in enumerate(vm.instrs) if i.op == 'LABEL'}
            vm.run()
        except Exception as e:
            print(f"Error: {e}")

def main():
    parser = argparse.ArgumentParser(description="RetroCalcLang Compiler")
    parser.add_argument("filename", nargs="?", help="Source file (.src)")
    parser.add_argument("--debug", action="store_true", help="Show compilation steps")
    parser.add_argument("--interactive", action="store_true", help="Start interactive mode")
    args = parser.parse_args()

    if args.interactive:
        repl()
        return

    if not args.filename:
        parser.print_help()
        sys.exit(0)

    try:
        with open(args.filename, 'r') as f: code = f.read()
    except FileNotFoundError:
        print(f"Error: File '{args.filename}' not found."); sys.exit(1)

    # 1. Lexical Analysis
    lexer = Lexer(code)
    tokens = lexer.tokenize()
    if args.debug: print("--- TOKENS ---\n", tokens)

    # 2. Syntax Analysis
    parser_obj = Parser(tokens)
    ast = parser_obj.parse()

    # 3. Semantic Analysis
    analyzer = SemanticAnalyzer()
    analyzer.analyze(ast)

    # 4. IR Generation
    ir_gen = TACGenerator()
    ir_gen.generate(ast)
    tac = ir_gen.instructions

    # 5. Optimization
    optimizer = Optimizer(tac)
    optimized_tac = optimizer.optimize()
    if args.debug:
        print("--- OPTIMIZED TAC ---")
        for instr in optimized_tac: print(instr)
        print("--- EXECUTION ---")

    # 6. Execution
    vm = VM(optimized_tac)
    vm.run()

if __name__ == "__main__":
    main()
